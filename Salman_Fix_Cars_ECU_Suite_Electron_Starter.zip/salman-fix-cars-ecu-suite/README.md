# Salman Fix Cars ECU Suite - Electron Starter

## Included
- Windows desktop Electron starter project
- Dark blue/red automotive design
- Dashboard
- DTC OFF page
- IMMO OFF page
- ECU file selector: BIN / HEX / ORI / ZIP / RAR
- File library demo
- License page demo
- WhatsApp support button

## Install
```bash
npm install
```

## Run
```bash
npm start
```

## Build Windows EXE installer
```bash
npm run dist
```

## Important
This is a starter UI/template. Real ECU functions such as DTC OFF, IMMO OFF, checksum correction, and ECU map detection require tested ECU algorithms and engineering.
