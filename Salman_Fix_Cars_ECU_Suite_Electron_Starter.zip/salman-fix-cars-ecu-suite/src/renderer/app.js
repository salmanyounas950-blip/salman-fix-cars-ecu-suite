const navButtons = document.querySelectorAll(".nav");
const pages = document.querySelectorAll(".page");
const title = document.getElementById("pageTitle");

const titles = {
  dashboard: "ECU Dashboard",
  dtc: "DTC OFF",
  immo: "IMMO OFF",
  library: "File Library",
  license: "License Activation"
};

navButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    navButtons.forEach(b => b.classList.remove("active"));
    pages.forEach(p => p.classList.remove("active-page"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.page).classList.add("active-page");
    title.textContent = titles[btn.dataset.page];
  });
});

document.getElementById("selectFileBtn").addEventListener("click", async () => {
  const file = await window.ecuAPI.selectFile();
  const info = document.getElementById("fileInfo");
  if (!file) {
    info.textContent = "No file selected";
    return;
  }
  info.innerHTML = `
    <strong>File:</strong> ${file.name}<br>
    <strong>Type:</strong> ${file.extension}<br>
    <strong>Size:</strong> ${(file.size / 1024).toFixed(2)} KB<br>
    <strong>Path:</strong> ${file.path}
  `;
});

document.getElementById("whatsappBtn").addEventListener("click", async () => {
  await window.ecuAPI.openWhatsApp();
});
