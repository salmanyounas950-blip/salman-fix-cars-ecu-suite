const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("ecuAPI", {
  selectFile: () => ipcRenderer.invoke("select-ecu-file"),
  saveModifiedFile: (fileName, content) => ipcRenderer.invoke("save-modified-file", fileName, content),
  openWhatsApp: () => ipcRenderer.invoke("open-whatsapp")
});
