const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 760,
    minWidth: 950,
    minHeight: 650,
    title: "Salman Fix Cars ECU Suite",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile(path.join(__dirname, "renderer", "index.html"));
}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

ipcMain.handle("select-ecu-file", async () => {
  const result = await dialog.showOpenDialog({
    title: "Select ECU File",
    filters: [
      { name: "ECU Files", extensions: ["bin", "hex", "ori", "rar", "zip"] },
      { name: "All Files", extensions: ["*"] }
    ],
    properties: ["openFile"]
  });

  if (result.canceled || result.filePaths.length === 0) return null;

  const filePath = result.filePaths[0];
  const stats = fs.statSync(filePath);

  return {
    path: filePath,
    name: path.basename(filePath),
    size: stats.size,
    extension: path.extname(filePath).replace(".", "").toUpperCase()
  };
});

ipcMain.handle("save-modified-file", async (_, fileName, content) => {
  const result = await dialog.showSaveDialog({
    title: "Save Modified ECU File",
    defaultPath: fileName || "modified_file.bin"
  });

  if (result.canceled || !result.filePath) return false;

  fs.writeFileSync(result.filePath, content || "Starter demo modified file");
  return result.filePath;
});

ipcMain.handle("open-whatsapp", async () => {
  await shell.openExternal("https://wa.me/966546292390");
});
